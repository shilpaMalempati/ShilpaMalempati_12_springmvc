package com.capgemini.springmvc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.springmvc.beans.EmployeeInfoBean;
import com.capgemini.springmvc.dao.EmployeeDAO;
import com.capgemini.springmvc.dao.EmployeeDAOJDBCImpl;

@Component
public class EmployeeServiceImpl implements EmployeeService{
	
//    private EmployeeDAO  dao= new EmployeeDAOJDBCImpl();
	@Autowired
	private EmployeeDAO  dao;
	
	@Override
	public EmployeeInfoBean authenticate(int empId, String password) {
		if(empId<1 || password==null || password.trim().isEmpty()) {
			return null;
		}
		return dao.authenticate(empId, password);
	}
 
	@Override
	public boolean addEmployee(EmployeeInfoBean employeeBean) {
		if(employeeBean !=null) {
			return dao.addEmployee(employeeBean);
		}
		return false;
	}

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeBean) {
	
		return dao.updateEmployee( employeeBean);
	}

	@Override
	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(empId);
	}

	@Override
	public EmployeeInfoBean getEmployee(int empId) {
		if(empId>0) {
			return dao.getEmployee(empId);
		}
		return null;
	}

	@Override
	public List<EmployeeInfoBean> getAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
