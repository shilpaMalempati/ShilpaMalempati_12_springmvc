package com.capgemini.springmvc.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.springmvc.beans.EmployeeInfoBean;
import com.capgemini.springmvc.services.EmployeeService;
import com.capgemini.springmvc.services.EmployeeServiceImpl;

@Controller
public class EmployeeController {
	
//	private EmployeeService service = new EmployeeServiceImpl();//instead of creating obj we r using @auto wired
	
	@Autowired
	private EmployeeService service;



	
	@GetMapping("/searchEmployeeForm")
	public String displaySearchEmployeeForm() {

//		return "/WEB-INF/views/searchEmployee.jsp";
		return "searchEmployee";

	}
	
	@PostMapping("/searchEmp")
	public String searchEmployee(@RequestParam(name="empId") int empIdVal,ModelMap modelMap) {
		EmployeeInfoBean  bean= service.getEmployee(empIdVal);
		if(bean!=null) {
		modelMap.addAttribute("empInfo",bean);
		}else {
			modelMap.addAttribute("errMsg", "emppoyeee not found");

		}
//		return "/WEB-INF/views/searchEmployee.jsp";
		return "searchEmployee";
		
	}
	
	@GetMapping("/searchEmp2")
	public String searchEmployee2(int empId,ModelMap modelMap) {
		EmployeeInfoBean  bean=service.getEmployee(empId);
		if(bean!=null) {
		modelMap.addAttribute("empInfo",bean);
		}else {
			modelMap.addAttribute("errMsg", "emppoyeee not found");

		}
//		return "/WEB-INF/views/searchEmployee.jsp";
		return "searchEmployee";
		
	}
	
	@GetMapping("/addEmployeeForm")
	public String displayAddEmployeeForm() {
		
		return "addEmployee";
		
	}
	
	@PostMapping("/addEmp")
	public String addEmployee(EmployeeInfoBean employeeBean,ModelMap modelMap) {
		//	public String addEmployee(int empId,String empName,String designation,double salary,int age) {
		//		
		//		EmployeeInfoBean employeeInfoBean= new EmployeeInfoBean();
		//		employeeInfoBean.setEmpId(empId);
		//        employeeInfoBean.setEmpName(empName);	
		//        employeeInfoBean.setDesignation(designation);
		//        

		boolean isAdded= service.addEmployee(employeeBean);
		if(isAdded) {
			modelMap.addAttribute("empInfo","Employee added sucessfull");
		}else {
			modelMap.addAttribute("errMsg", "unable to add emppoyeee data");

		}


		return "addEmployee";
	}
	
	
	@GetMapping("/updateEmployeeForm")
	public String displayUpdateEmployeeForm() {

		return "updateEmployee";

	}
	
	@GetMapping("/updateEmp")
	public String updateEmployee(EmployeeInfoBean employeeBean,ModelMap modelMap) {
		
		boolean  isUpdated = service.updateEmployee(employeeBean);
		
		if(isUpdated) {
			modelMap.addAttribute("empInfo","Employee updated sucessfull");
		}else {
			modelMap.addAttribute("errMsg", "unable to update emppoyeee data");

		}

		return "updateEmployee";
		
	}
	
	
	@GetMapping("/deleteEmployeeForm")
	public String diplayDeleteEmployeeForm() {

		return "deleteEmployee";

	}
	
	@GetMapping("/deleteEmp")
	public String  deleteEmployee(@RequestParam(name="empId") int empIdVal,ModelMap modelMap) {
		
		boolean isAdded= service.deleteEmployee(empIdVal);
		if(isAdded) {
			modelMap.addAttribute("empInfo","Employee deleted sucessfull");
		}else {
			modelMap.addAttribute("errMsg", "unable to delete emppoyeee data");

		}
		return "deleteEmployee";
		
	}


	@GetMapping("/allEmployeesDetails")
	public String dispalyAllEmployee() {
		
		return "getAllEmployees";
	}

	@GetMapping("/allEmpDet")
	public String allEmployee(EmployeeInfoBean bean,ModelMap modelMap) {
			
		List<EmployeeInfoBean> bean1=service.getAllEmployee();
	
		if(bean1!=null && !bean1.isEmpty()) {
			modelMap.addAttribute("msg", bean1);
		}
		else {
			modelMap.addAttribute("errMsg", "EmployeeDetails are not available");
		}
		return "getAllEmployees";
	
	}

	
}
