package com.capgemini.springmvc.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.capgemini.springmvc.beans.PersonBean;

//@Controller
public class Datecontroller {
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		CustomDateEditor dateEditor = new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true);
		binder.registerCustomEditor(Date.class,dateEditor);
	}

	 @GetMapping("./personDetails")
	 public String showPersonDetailsPage() {
		 
		 return "personDetails";
	 }
	 
	 @PostMapping(name="./submitPerson")
	 public String submitPersonDetails(PersonBean personBean,ModelMap map ) {
		 
		  map.addAttribute(personBean);
		  
		 return "personDetails";
	 }
}
