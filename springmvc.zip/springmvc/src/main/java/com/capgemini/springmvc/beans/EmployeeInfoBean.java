package com.capgemini.springmvc.beans;

import java.util.Date;

import lombok.Data;

@Data
public class EmployeeInfoBean {
	private int empId;
	private String empName;
	private int age;
	private double salary;
	private String designation;
//	private Date doj;
	private String password;


}
