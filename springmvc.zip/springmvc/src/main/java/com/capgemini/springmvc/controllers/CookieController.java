package com.capgemini.springmvc.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;

//@Controller
public class CookieController {


	@GetMapping("./cookiePage")
	public String displayCookiePage() {
		return "cookiePage";
	}
	
	@GetMapping(name="./createCookie")
	public String createCookie(HttpServletResponse resp,ModelMap map) {
		Cookie cookie= new Cookie("companyname","capgemini");
		resp.addCookie(cookie);
		
		map.addAttribute("msg","cookie added succefuuly");
		
		return "cookiePage";
		
	}
	
	@GetMapping(name="./readCookie")
	public String readCookie(@CookieValue(name="companyname") String companyname,ModelMap map) {
		
			map.addAttribute("msg","cookie value is"+ companyname);
		
		return "cookiePage";
		
	}
	
}
