package com.capgemini.springmvc.beans;

import java.util.Date;

import lombok.Data;

@Data
public class PersonBean {
 private String personName;
 private Date dob;
}
