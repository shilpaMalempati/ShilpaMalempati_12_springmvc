package com.capgemini.springmvc.dao;

import java.util.List;

import com.capgemini.springmvc.beans.EmployeeInfoBean;

public interface EmployeeDAO {
   public EmployeeInfoBean authenticate(int empId, String password);
	
	public boolean addEmployee(EmployeeInfoBean employeeBean);
	public boolean updateEmployee(EmployeeInfoBean employeeBean);
	public boolean deleteEmployee(int empId);
	public EmployeeInfoBean getEmployee(int empId);
	public List<EmployeeInfoBean> getAllEmployee();
}
